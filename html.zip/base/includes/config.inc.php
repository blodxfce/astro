<?php
###############################################
# Site configuration
###############################################
$db_host="localhost";
$db_user="geral";
$db_pass="988112077";
$db_name="revenda-4";
$table_prefix="ogp_";
$db_type="mysql";
?>
