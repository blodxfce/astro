<?php

namespace PhpXmlRpc;

class Exception extends \Exception
{
}
