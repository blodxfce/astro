<?php

namespace PhpXmlRpc\Exception;

use PhpXmlRpc\Exception as BaseExtension;

/**
 * To be used when throwing exceptions instead of returning Response objects (future API?)
 */
class FaultResponseException extends BaseExtension
{
}
