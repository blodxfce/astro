<?php

namespace PhpXmlRpc\Exception;

class NoSuchMethodException extends ServerException
{
}
