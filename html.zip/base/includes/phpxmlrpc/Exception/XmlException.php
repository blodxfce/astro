<?php

namespace PhpXmlRpc\Exception;

class XmlException extends ParsingException
{
}
