<?php

namespace PhpXmlRpc\Exception;

class XmlRpcException extends ParsingException
{
}
